<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\Controller;

class UsersController extends Controller{

  public function postLogin(Request $request)
  {
    $credentials = $request->only('email', 'password');
    //print_r($credentials);
    if(Auth::attempt($credentials)){
        return Redirect::route('admin_area');
    }
    else(print_r('wrong input'));

  }
  
  public function getLogout()
  {
    Auth::logout();
    return Redirect::route('index');
  }
}
