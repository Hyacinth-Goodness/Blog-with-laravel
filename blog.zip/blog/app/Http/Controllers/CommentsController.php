<?php
namespace App\Http\Controllers;

use App\Comment;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;

class CommentsController extends Controller{
  
    public function getComment($post_id)
    {
        $comments = Comment::with('Post')->where('post_id', '=', $post_id)-> orderBy('id', 'DESC')->get();
        return View::make('comments')->with('comments',$comments)->with('post_id',$post_id);
  
    }
    public function commentAdd($post_id)
    {
        Comment::create(array(
            'name' => Input::get('name'),
            'content' => Input::get('content'),
            'post_id' => $post_id
        ));
        return Redirect::route('comments',['post_id' => $post_id]);
    }
}