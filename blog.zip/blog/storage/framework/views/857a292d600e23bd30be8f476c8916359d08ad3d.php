<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>My Awesome Blog</title>
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        
        <link rel="stylesheet" href="/public/css/app.css" type="text/css" media="screen" />
        <link rel="stylesheet" type="text/css" href="/public/css/app.css" media="print" />
        <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    </head>
    <body>
        <div id="wrapper">
            <header class='container'>
                <h1><a href="/">My Awesome Blog</a></h1>
                <p><p><small><a href='/#<?php echo e($post_id); ?>'>Go back</a></small></p>
                <hr>
            </header>
            <section>
                <aside>
                    <section id="main">
                        <section class="container" id="content">
                            
                            <article>
                            
                                
                                
                                
                                
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <section>
                                    <p><b><?php echo e($comment->name); ?>: </b><?php echo e($comment->content); ?> </p>
                                    <p><small>Posted at <b><?php echo e($comment->created_at); ?></b></small></p>
                                </section>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </article>
                            <p id= 'add_comment'>Add Comment</p>
                            <form name="add_comment" method="POST" action="<?php echo e(URL::route('add_new_comment',['post_id' => $post_id])); ?>">
                                <?php echo csrf_field(); ?>
                                <p><input type="text" name="name" placeholder="Name" value=""/></p>
                                <p><textarea name="content" placeholder="Comment"></textarea></p>
                                <p><input type="submit" name="submit"/></p>
                            </form>

                            
                        </section>
                    </section>
                </aside>
            </section>
            <footer>
                <section class='container' id="footer-area">
                    <section id="footer-outer-block">
                        <aside class="footer-segment">
                            <h4>My Awesome Blog</h4>
                        </aside>
                    </section>
                </section>
            </footer>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    </body>
</html>