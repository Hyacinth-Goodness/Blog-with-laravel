<html>
    <head>
    <title>Welcome to Your Blog</title>
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/css/app.css">
        <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    </head>
    <body>
        @if(Auth::check())
            <section class="container">
                <div class="content">
                    <h1>Welcome to Admin Area, {{Auth::user()->name}} ! - <b><a href='{{URL::route('logout')}}'>Logout</a></b></h1>
                    <hr>
                    <form name="add_post" method="POST" action="{{URL::route('add_new_post')}}">
                        @csrf
                        <p><input type="text" name="title" placeholder="Post Title" value=""/></p>
                        <p><textarea name="content" placeholder="Post Content"></textarea></p>
                        <p><input type="submit" name="submit" /></p>
                    </form>
                </div>
            </section>
        @else
            <section class="container">
                <div class="login">
                    <h1>Please Login</h1>
                    <form name="login" method="POST" action="{{URL::route('login')}}">
                        @csrf
                        <p><input type="text" name="email" value="" placeholder="Email"></p>
                        <p><input type="password" name="password" value="" placeholder="Password"></p>
                        <p class="submit"><input type="submit" name="commit" value="Login"></p>
                    </form>
                </div>
            </section>
        @endif
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    </body>
</html>
