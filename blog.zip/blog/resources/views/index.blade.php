<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>My Awesome Blog</title>
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
        <link rel="stylesheet" href="css/app.css" type="text/css" media="screen" />
        <link rel="stylesheet" type="text/css" href="/css/app.css" media="print" />
        <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    </head>
    <body>
        <div id="wrapper">
            <header class= "container" >
                <h1><a href="/">THE BLOG</a></h1>
                <p>Welcome to this very basic blog</p>
                <hr>
            </header>
            <section class="container">
                <aside>
                    <section id="main">
                        <section id="content">
                            @foreach($posts as $post)
                            <article>
                                <h2 id='{{$post->id}}'>{{$post->title}}</h2>
                                <p>{{$post->content}}</p>
                                <p><small>Posted by <b>{{$post->Author->name}}</b> at <b>{{$post->created_at}}</b></small></p>
                                <p><small><a href='/comments/{{$post->id}}'>View Comments</a></small> | <small><a href='/comments/{{$post->id}}#add_comment'>Add Comments</a></small></p>
                            </article>

                            @endforeach
                        </section>
                        {{$posts->links()}}
                    </section>
                </aside>
            </section>
            <footer>
                <section id="footer-area">
                    <section id="footer-outer-block">
                        <aside class="footer-segment">
                            <h4>My Awesome Blog</h4>
                        </aside>
                    </section>
                </section>
            </footer>
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    </body>
</html>